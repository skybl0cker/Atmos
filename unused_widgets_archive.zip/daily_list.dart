import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';
import 'glass_card.dart';
import 'weather_icon.dart';

const _white70 = Colors.white70;
const _white = Colors.white;

/// Maps an absolute temperature (°C) onto a cold → hot color ramp, so the
/// range bars read at a glance: blue for freezing, green for mild, orange
/// and red for hot days.
Color tempColor(double c) {
  const stops = <(double, Color)>[
    (-10, Color(0xFF7B8CFF)),
    (0, Color(0xFF5EC8FF)),
    (10, Color(0xFF6EE7C8)),
    (18, Color(0xFFB8E86B)),
    (25, Color(0xFFFFD166)),
    (31, Color(0xFFFF9F43)),
    (38, Color(0xFFFF5E5E)),
  ];
  if (c <= stops.first.$1) return stops.first.$2;
  for (var i = 1; i < stops.length; i++) {
    if (c <= stops[i].$1) {
      final a = stops[i - 1], b = stops[i];
      final t = (c - a.$1) / (b.$1 - a.$1);
      return Color.lerp(a.$2, b.$2, t)!;
    }
  }
  return stops.last.$2;
}

/// Expandable daily forecast list with temperature range bars. Used on the
/// home screen (7 days) and the full 14-day forecast tab.
class DailyList extends StatelessWidget {
  final String title;
  final int maxDays;
  const DailyList({super.key, required this.title, this.maxDays = 7});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final data = s.data!;
    final all = data.daily;
    if (all.isEmpty) return const SizedBox.shrink();
    final days = all.length > maxDays ? all.sublist(0, maxDays) : all;
    final minAll = days.map((d) => d.minC).reduce(math.min);
    final maxAll = days.map((d) => d.maxC).reduce(math.max);
    final range = math.max(maxAll - minAll, 1.0);
    final nowC = data.current.tempC;

    return GlassCard(
      title: title,
      icon: Icons.calendar_month,
      padding: const EdgeInsets.fromLTRB(6, 14, 6, 6),
      child: Theme(
        data: Theme.of(context).copyWith(
          dividerColor: Colors.transparent,
          colorScheme: Theme.of(context).colorScheme.copyWith(primary: _white),
        ),
        child: Column(
          children: [
            for (var i = 0; i < days.length; i++)
              Container(
                margin: const EdgeInsets.symmetric(vertical: 1),
                decoration: BoxDecoration(
                  color: i == 0 ? Colors.white.withAlpha(22) : null,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: ExpansionTile(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                  collapsedShape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                  backgroundColor: Colors.white.withAlpha(14),
                  tilePadding: const EdgeInsets.symmetric(horizontal: 10),
                  iconColor: _white70,
                  collapsedIconColor: _white70,
                  title: Row(
                    children: [
                      SizedBox(
                        width: 52,
                        child: Text(
                          i == 0 ? 'Today' : DateFormat.E().format(days[i].date),
                          style: TextStyle(
                              color: _white,
                              fontSize: 15,
                              fontWeight:
                                  i == 0 ? FontWeight.w700 : FontWeight.w500),
                        ),
                      ),
                      WeatherIcon(days[i].code, day: true, size: 22),
                      SizedBox(
                        width: 38,
                        child: Text(
                          days[i].precipProb >= 20
                              ? ' ${days[i].precipProb}%'
                              : '',
                          style: const TextStyle(
                              color: Color(0xFF9BE7FF),
                              fontSize: 11,
                              fontWeight: FontWeight.w700),
                        ),
                      ),
                      SizedBox(
                        width: 38,
                        child: Text(s.temp(days[i].minC),
                            textAlign: TextAlign.right,
                            softWrap: false,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: _white70)),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: LayoutBuilder(builder: (_, box) {
                          final w = box.maxWidth;
                          final lo = days[i].minC, hi = days[i].maxC;
                          final left = (lo - minAll) / range * w;
                          final width = math.max((hi - lo) / range * w, 6.0);
                          // Current-temperature marker on today's bar.
                          final showNow =
                              i == 0 && nowC >= lo - 0.5 && nowC <= hi + 0.5;
                          final nowX = ((nowC - minAll) / range * w)
                              .clamp(3.0, math.max(w - 3, 3.0))
                              .toDouble();
                          return SizedBox(
                            height: 10,
                            child: Stack(
                              clipBehavior: Clip.none,
                              children: [
                                Positioned(
                                  left: 0,
                                  right: 0,
                                  top: 2.5,
                                  height: 5,
                                  child: DecoratedBox(
                                    decoration: BoxDecoration(
                                      color: Colors.white.withAlpha(36),
                                      borderRadius: BorderRadius.circular(3),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  left: left
                                      .clamp(0.0, math.max(w - 6, 0.0))
                                      .toDouble(),
                                  width: width,
                                  top: 2.5,
                                  height: 5,
                                  child: DecoratedBox(
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(colors: [
                                        tempColor(lo),
                                        tempColor(hi),
                                      ]),
                                      borderRadius: BorderRadius.circular(3),
                                    ),
                                  ),
                                ),
                                if (showNow)
                                  Positioned(
                                    left: nowX - 5,
                                    top: 0,
                                    child: Container(
                                      width: 10,
                                      height: 10,
                                      decoration: BoxDecoration(
                                        color: _white,
                                        shape: BoxShape.circle,
                                        border: Border.all(
                                            color: const Color(0xFF2A1F5C),
                                            width: 2),
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                          );
                        }),
                      ),
                      const SizedBox(width: 8),
                      SizedBox(
                        width: 38,
                        child: Text(s.temp(days[i].maxC),
                            softWrap: false,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                color: _white, fontWeight: FontWeight.w700)),
                      ),
                    ],
                  ),
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(12, 0, 12, 14),
                      child: Row(
                        children: [
                          _dayFact(Icons.water_drop_outlined, 'Rain',
                              '${days[i].precipProb}%'),
                          _dayFact(Icons.wb_sunny_outlined, 'UV',
                              days[i].uv.round().toString()),
                          _dayFact(Icons.wb_twilight, 'Sunrise',
                              DateFormat.jm().format(days[i].sunrise)),
                          _dayFact(Icons.nights_stay_outlined, 'Sunset',
                              DateFormat.jm().format(days[i].sunset)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _dayFact(IconData icon, String label, String value) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 3),
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 6),
        decoration: BoxDecoration(
          color: Colors.white.withAlpha(16),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Icon(icon, size: 16, color: _white70),
            const SizedBox(height: 4),
            Text(label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: _white70, fontSize: 10)),
            Text(value,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    color: _white, fontSize: 13, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}
