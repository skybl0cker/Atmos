import 'dart:math' as math;
import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';

import '../models/weather.dart';
import 'weather_background.dart';

/// Where the sun is in its day: drives both the sky palette and where the
/// sun / moon glow sits.
enum SkyPhase { dawn, day, dusk, night }

class SkyState {
  final SkyPhase phase;

  /// 0 at sunrise → 1 at sunset (only meaningful during the day).
  final double sunProgress;
  final int code;
  final bool isDay;
  const SkyState(this.phase, this.sunProgress, this.code, this.isDay);

  static SkyState of(WeatherData? d) {
    if (d == null) return const SkyState(SkyPhase.day, 0.5, 1, true);
    final c = d.current;
    if (d.daily.isEmpty) {
      return SkyState(
          c.isDay ? SkyPhase.day : SkyPhase.night, 0.5, c.code, c.isDay);
    }
    final today = d.daily.first;
    final now = c.time;
    final rise = today.sunrise, set = today.sunset;
    const edge = Duration(minutes: 50);
    final span = set.difference(rise).inSeconds.toDouble();
    final progress = span <= 0
        ? 0.5
        : (now.difference(rise).inSeconds / span).clamp(0.0, 1.0).toDouble();

    SkyPhase phase;
    if (now.isAfter(rise.subtract(edge)) && now.isBefore(rise.add(edge))) {
      phase = SkyPhase.dawn;
    } else if (now.isAfter(set.subtract(edge)) &&
        now.isBefore(set.add(edge))) {
      phase = SkyPhase.dusk;
    } else if (c.isDay) {
      phase = SkyPhase.day;
    } else {
      phase = SkyPhase.night;
    }
    return SkyState(phase, progress, c.code, c.isDay);
  }

  bool get clearish => code <= 2;
  bool get stormy => code >= 95;
  bool get rainy => (code >= 51 && code <= 67) || (code >= 80 && code <= 82);
  bool get snowy => (code >= 71 && code <= 77) || code == 85 || code == 86;
  bool get foggy => code == 45 || code == 48;
  bool get dark => phase == SkyPhase.night || stormy;
}

/// Top → bottom sky gradient for the conditions and time of day.
List<Color> skyColors(SkyState s) {
  final night = s.phase == SkyPhase.night;
  if (s.stormy) {
    return const [Color(0xFF10131B), Color(0xFF232838), Color(0xFF3A4156)];
  }
  if (s.rainy) {
    return night
        ? const [Color(0xFF080C18), Color(0xFF131C2E), Color(0xFF22304A)]
        : const [Color(0xFF26364D), Color(0xFF3F5673), Color(0xFF677F9C)];
  }
  if (s.snowy) {
    return night
        ? const [Color(0xFF0D1426), Color(0xFF1D2A45), Color(0xFF3A4A6A)]
        : const [Color(0xFF4E6A91), Color(0xFF7F99BC), Color(0xFFBFCDE0)];
  }
  if (s.foggy) {
    return night
        ? const [Color(0xFF15191F), Color(0xFF262C35), Color(0xFF3B424D)]
        : const [Color(0xFF56616F), Color(0xFF7D8896), Color(0xFFA9B1BC)];
  }
  if (s.code == 3) {
    return night
        ? const [Color(0xFF0C111D), Color(0xFF19202F), Color(0xFF2B3447)]
        : const [Color(0xFF41566F), Color(0xFF627A96), Color(0xFF93A6BD)];
  }
  // Clear / partly cloudy: the time of day carries the mood.
  switch (s.phase) {
    case SkyPhase.dawn:
      return const [Color(0xFF253370), Color(0xFF9A5F92), Color(0xFFF2A97F)];
    case SkyPhase.dusk:
      return const [Color(0xFF1A1E55), Color(0xFF7D4488), Color(0xFFEE8556)];
    case SkyPhase.night:
      return const [Color(0xFF050817), Color(0xFF0E1638), Color(0xFF1E2B5C)];
    case SkyPhase.day:
      return s.code == 2
          ? const [Color(0xFF2659A8), Color(0xFF4E87CF), Color(0xFF9CC2E8)]
          : const [Color(0xFF1652B5), Color(0xFF3786E0), Color(0xFF86C1F5)];
  }
}

/// A full-bleed living sky: an animated gradient that eases between
/// palettes, a sun or moon glow placed by the real sun position, and the
/// rain / snow / star / lightning particle layer on top.
class SkyBackground extends StatelessWidget {
  final SkyState sky;
  final Widget child;
  const SkyBackground({super.key, required this.sky, required this.child});

  @override
  Widget build(BuildContext context) {
    final colors = skyColors(sky);
    return AnimatedContainer(
      duration: const Duration(milliseconds: 1400),
      curve: Curves.easeInOut,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: colors,
          stops: const [0.0, 0.55, 1.0],
        ),
      ),
      child: Stack(
        fit: StackFit.expand,
        children: [
          IgnorePointer(
            child: TweenAnimationBuilder<double>(
              tween: Tween(end: sky.sunProgress),
              duration: const Duration(milliseconds: 1400),
              curve: Curves.easeInOut,
              builder: (_, p, _) => CustomPaint(
                painter: _OrbPainter(
                  progress: p,
                  night: sky.phase == SkyPhase.night,
                  // Hide the orb behind solid overcast / precipitation.
                  strength: sky.clearish
                      ? 1.0
                      : (sky.code == 3 || sky.foggy)
                          ? 0.25
                          : 0.0,
                  warm: sky.phase == SkyPhase.dawn ||
                      sky.phase == SkyPhase.dusk,
                ),
              ),
            ),
          ),
          WeatherBackground(code: sky.code, isDay: sky.isDay, child: child),
        ],
      ),
    );
  }
}

class _OrbPainter extends CustomPainter {
  final double progress;
  final bool night;
  final double strength;
  final bool warm;
  _OrbPainter({
    required this.progress,
    required this.night,
    required this.strength,
    required this.warm,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (strength <= 0) return;
    final w = size.width, h = size.height;
    final Offset c;
    final Color core, glow;
    final double r;
    if (night) {
      c = Offset(w * 0.8, h * 0.13);
      core = const Color(0xFFF4F1E6);
      glow = const Color(0xFFB9C6FF);
      r = 22;
    } else {
      // Arc across the upper sky from sunrise (left) to sunset (right).
      c = Offset(
        w * (0.08 + 0.84 * progress),
        h * (0.34 - 0.24 * math.sin(math.pi * progress)),
      );
      core = warm ? const Color(0xFFFFD9A0) : const Color(0xFFFFF6D6);
      glow = warm ? const Color(0xFFFF9E5E) : const Color(0xFFFFE08A);
      r = 34;
    }
    final glowR = r * (night ? 6 : 9);
    canvas.drawCircle(
      c,
      glowR,
      Paint()
        ..shader = RadialGradient(colors: [
          glow.withAlpha((110 * strength).round()),
          glow.withAlpha((40 * strength).round()),
          glow.withAlpha(0),
        ], stops: const [
          0.0,
          0.35,
          1.0
        ]).createShader(Rect.fromCircle(center: c, radius: glowR)),
    );
    // Draw the disc on its own layer so the moon's crescent can be carved
    // out without punching a hole in the glow behind it.
    canvas.saveLayer(Rect.fromCircle(center: c, radius: r * 2), Paint());
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..color = core.withAlpha((235 * strength).round())
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, night ? 1.2 : 4),
    );
    if (night) {
      canvas.drawCircle(
        c + const Offset(10, -7),
        r * 0.88,
        Paint()..blendMode = BlendMode.dstOut,
      );
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(_OrbPainter old) =>
      old.progress != progress ||
      old.night != night ||
      old.strength != strength ||
      old.warm != warm;
}

/// The frosted glass surface used throughout the new UI.
class Glass extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;

  /// Smoky variant for chrome that floats over content (the dock).
  final bool smoky;
  const Glass({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.radius = 26,
    this.smoky = false,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: smoky ? 24 : 18, sigmaY: smoky ? 24 : 18),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(radius),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: smoky
                  ? [
                      const Color(0xFF0B1024).withAlpha(150),
                      const Color(0xFF0B1024).withAlpha(110),
                    ]
                  : [
                      Colors.white.withAlpha(40),
                      Colors.white.withAlpha(16),
                    ],
            ),
            border: Border.all(color: Colors.white.withAlpha(46)),
          ),
          child: child,
        ),
      ),
    );
  }
}
