import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:intl/intl.dart' show DateFormat;

import '../models/weather.dart';
import '../state/app_state.dart';
import '../utils/summary.dart';
import '../utils/weather_codes.dart';
import 'sky_background.dart';

const _soft = Color(0xB3FFFFFF); // white 70%
const _faint = Color(0x40FFFFFF);

/// Square glass tile with a small caps header.
class DetailTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final Widget child;
  const DetailTile(
      {super.key, required this.icon, required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1,
      child: Glass(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Icon(icon, size: 14, color: _soft),
              const SizedBox(width: 5),
              Flexible(
                child: Text(title.toUpperCase(),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        color: _soft,
                        fontSize: 11,
                        letterSpacing: 1.1,
                        fontWeight: FontWeight.w700)),
              ),
            ]),
            const SizedBox(height: 8),
            Expanded(child: child),
          ],
        ),
      ),
    );
  }
}

TextStyle _big([double size = 30]) => TextStyle(
    color: Colors.white,
    fontSize: size,
    fontWeight: FontWeight.w300,
    height: 1.0,
    letterSpacing: -0.5);

const _note = TextStyle(color: _soft, fontSize: 12, height: 1.25);

// ---------------------------------------------------------------- wind ---

class WindTile extends StatelessWidget {
  final AppState s;
  final CurrentWeather c;
  const WindTile({super.key, required this.s, required this.c});

  @override
  Widget build(BuildContext context) {
    final speed = s.wind(c.windKmh).split(' ');
    return DetailTile(
      icon: Icons.air_rounded,
      title: 'Wind',
      child: LayoutBuilder(builder: (_, box) {
        final d = math.min(box.maxWidth, box.maxHeight);
        return Center(
          child: SizedBox(
            width: d,
            height: d,
            child: Stack(
              alignment: Alignment.center,
              children: [
                CustomPaint(
                    size: Size(d, d),
                    painter: _CompassPainter(c.windDir.toDouble())),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(speed.first, style: _big(d * 0.22)),
                    Text(speed.length > 1 ? speed[1] : '',
                        style: const TextStyle(color: _soft, fontSize: 11)),
                  ],
                ),
              ],
            ),
          ),
        );
      }),
    );
  }
}

class _CompassPainter extends CustomPainter {
  final double fromDeg;
  _CompassPainter(this.fromDeg);

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2 - 2;
    final tick = Paint()
      ..color = _faint
      ..strokeWidth = 1.2;
    for (var i = 0; i < 72; i++) {
      final a = i * 5 * math.pi / 180;
      final major = i % 18 == 0;
      final inner = r - (major ? 9 : 5);
      canvas.drawLine(
        c + Offset(math.sin(a), -math.cos(a)) * inner,
        c + Offset(math.sin(a), -math.cos(a)) * r,
        major ? (Paint()..color = _soft..strokeWidth = 1.6) : tick,
      );
    }
    const labels = ['N', 'E', 'S', 'W'];
    for (var i = 0; i < 4; i++) {
      final a = i * math.pi / 2;
      final tp = TextPainter(
        text: TextSpan(
            text: labels[i],
            style: TextStyle(
                color: i == 0 ? Colors.white : _soft,
                fontSize: 10,
                fontWeight: FontWeight.w800)),
        textDirection: TextDirection.ltr,
      )..layout();
      final p = c + Offset(math.sin(a), -math.cos(a)) * (r - 19);
      tp.paint(canvas, p - Offset(tp.width / 2, tp.height / 2));
    }
    // Arrow points the way the wind is blowing (from → toward).
    final a = (fromDeg + 180) * math.pi / 180;
    final dir = Offset(math.sin(a), -math.cos(a));
    final tip = c + dir * (r - 4);
    final tail = c - dir * (r - 4);
    final arrow = Paint()
      ..color = Colors.white
      ..strokeWidth = 2.2
      ..strokeCap = StrokeCap.round;
    // Split the shaft so the speed readout in the centre stays clear.
    canvas.drawLine(tail, c - dir * (r * 0.42), arrow);
    canvas.drawLine(c + dir * (r * 0.42), tip, arrow);
    canvas.drawCircle(tail, 3.5, Paint()..color = Colors.white);
    final perp = Offset(-dir.dy, dir.dx);
    final head = Path()
      ..moveTo(tip.dx, tip.dy)
      ..lineTo((tip - dir * 10 + perp * 6).dx, (tip - dir * 10 + perp * 6).dy)
      ..lineTo((tip - dir * 10 - perp * 6).dx, (tip - dir * 10 - perp * 6).dy)
      ..close();
    canvas.drawPath(head, Paint()..color = Colors.white);
  }

  @override
  bool shouldRepaint(_CompassPainter old) => old.fromDeg != fromDeg;
}

// ----------------------------------------------------------------- sun ---

class SunTile extends StatelessWidget {
  final WeatherData d;
  const SunTile({super.key, required this.d});

  @override
  Widget build(BuildContext context) {
    final now = d.current.time;
    final today = d.daily.first;
    final tomorrow = d.daily.length > 1 ? d.daily[1] : null;
    final beforeRise = now.isBefore(today.sunrise);
    final afterSet = now.isAfter(today.sunset);
    final span = today.sunset.difference(today.sunrise).inSeconds;
    final progress = span <= 0
        ? 0.5
        : (now.difference(today.sunrise).inSeconds / span)
            .clamp(0.0, 1.0)
            .toDouble();

    final String headline, label, note;
    if (beforeRise || (afterSet && tomorrow != null)) {
      final rise = beforeRise ? today.sunrise : tomorrow!.sunrise;
      headline = DateFormat.jm().format(rise);
      label = 'Sunrise';
      note = 'Sunset ${DateFormat.jm().format(beforeRise ? today.sunset : tomorrow!.sunset)}';
    } else {
      headline = DateFormat.jm().format(today.sunset);
      label = 'Sunset';
      final left = today.sunset.difference(now);
      note = '${left.inHours}h ${left.inMinutes % 60}m of light left';
    }

    return DetailTile(
      icon: label == 'Sunset'
          ? Icons.wb_twilight_rounded
          : Icons.wb_sunny_outlined,
      title: label,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          FittedBox(child: Text(headline, style: _big(26))),
          Expanded(
            child: CustomPaint(
              size: Size.infinite,
              painter: _SunArcPainter(
                  progress: progress, up: !beforeRise && !afterSet),
            ),
          ),
          Text(note, style: _note, maxLines: 1, overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }
}

class _SunArcPainter extends CustomPainter {
  final double progress;
  final bool up;
  _SunArcPainter({required this.progress, required this.up});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final base = h * 0.86;
    // Half-ellipse sitting on the horizon, peaking just inside the top.
    final ry = base - 10;
    final rect = Rect.fromLTRB(8, base - ry, w - 8, base + ry);
    // Horizon.
    canvas.drawLine(Offset(0, base), Offset(w, base),
        Paint()
          ..color = _faint
          ..strokeWidth = 1);
    // Full dashed path of the day.
    final arc = Path()..addArc(rect, math.pi, math.pi);
    for (final m in arc.computeMetrics()) {
      for (double t = 0; t < m.length; t += 7) {
        canvas.drawPath(
            m.extractPath(t, math.min(t + 3.5, m.length)),
            Paint()
              ..color = _faint
              ..style = PaintingStyle.stroke
              ..strokeWidth = 1.6);
      }
      if (up) {
        // Travelled part, solid and warm.
        canvas.drawPath(
            m.extractPath(0, m.length * progress),
            Paint()
              ..shader = const LinearGradient(
                      colors: [Color(0xFFFF9E5E), Color(0xFFFFE08A)])
                  .createShader(rect)
              ..style = PaintingStyle.stroke
              ..strokeCap = StrokeCap.round
              ..strokeWidth = 2.6);
        final pos =
            m.getTangentForOffset(m.length * progress)?.position ?? Offset.zero;
        canvas.drawCircle(pos, 11,
            Paint()..color = const Color(0xFFFFE08A).withAlpha(70));
        canvas.drawCircle(pos, 6, Paint()..color = const Color(0xFFFFE9A8));
      }
    }
  }

  @override
  bool shouldRepaint(_SunArcPainter old) =>
      old.progress != progress || old.up != up;
}

// ------------------------------------------------------------------ UV ---

class UvTile extends StatelessWidget {
  final DailyPoint today;
  const UvTile({super.key, required this.today});

  @override
  Widget build(BuildContext context) {
    final uv = today.uv;
    final frac = (uv / 11).clamp(0.0, 1.0).toDouble();
    return DetailTile(
      icon: Icons.wb_sunny_outlined,
      title: 'UV index',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('${uv.round()}', style: _big(40)),
          const SizedBox(height: 2),
          Text(uvLabel(uv),
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600)),
          const Spacer(),
          _GradientMeter(
            frac: frac,
            colors: const [
              Color(0xFF4CD964),
              Color(0xFFFFE14D),
              Color(0xFFFF9F43),
              Color(0xFFFF5E5E),
              Color(0xFFB36BD1),
            ],
          ),
          const SizedBox(height: 8),
          Text(
              uv >= 6
                  ? 'Peak today. Sun protection recommended.'
                  : uv >= 3
                      ? 'Peak today. Some protection midday.'
                      : 'Low all day.',
              style: _note,
              maxLines: 2,
              overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }
}

class _GradientMeter extends StatelessWidget {
  final double frac;
  final List<Color> colors;
  const _GradientMeter({required this.frac, required this.colors});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (_, box) {
      final w = box.maxWidth;
      return SizedBox(
        height: 12,
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Positioned(
              left: 0,
              right: 0,
              top: 3.5,
              height: 5,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(3),
                  gradient: LinearGradient(colors: colors),
                ),
              ),
            ),
            Positioned(
              left: (frac * w - 6).clamp(0.0, math.max(w - 12, 0.0)).toDouble(),
              top: 0,
              child: Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(color: Colors.black.withAlpha(60), blurRadius: 4),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
    });
  }
}

// ------------------------------------------------------------ humidity ---

class HumidityTile extends StatelessWidget {
  final AppState s;
  final CurrentWeather c;
  const HumidityTile({super.key, required this.s, required this.c});

  @override
  Widget build(BuildContext context) {
    final dew = dewPointC(c.tempC, c.humidity);
    final frac = (c.humidity / 100).clamp(0.0, 1.0).toDouble();
    return DetailTile(
      icon: Icons.water_drop_outlined,
      title: 'Humidity',
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${c.humidity.round()}%', style: _big(36)),
                const Spacer(),
                Text('Dew point', style: _note),
                Text(s.temp(dew),
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w600)),
                const SizedBox(height: 4),
                Text(
                    dew >= 18
                        ? 'Muggy'
                        : dew >= 13
                            ? 'Comfortable'
                            : 'Dry and crisp',
                    style: _note),
              ],
            ),
          ),
          const SizedBox(width: 10),
          // Vertical "fill" gauge.
          Container(
            width: 14,
            decoration: BoxDecoration(
              color: Colors.white.withAlpha(22),
              borderRadius: BorderRadius.circular(8),
            ),
            alignment: Alignment.bottomCenter,
            child: FractionallySizedBox(
              heightFactor: math.max(frac, 0.02),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  gradient: const LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [Color(0xFF2E9BFF), Color(0xFF9BE7FF)],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------- feels like ---

class FeelsLikeTile extends StatelessWidget {
  final AppState s;
  final CurrentWeather c;
  const FeelsLikeTile({super.key, required this.s, required this.c});

  @override
  Widget build(BuildContext context) {
    final diff = c.feelsC - c.tempC;
    final String why;
    if (diff <= -2) {
      why = c.windKmh >= 15
          ? 'Wind is making it feel colder.'
          : 'Feels cooler than it is.';
    } else if (diff >= 2) {
      why = c.humidity >= 50
          ? 'Humidity is making it feel warmer.'
          : 'Sun is making it feel warmer.';
    } else {
      why = 'Similar to the actual temperature.';
    }
    return DetailTile(
      icon: Icons.thermostat_rounded,
      title: 'Feels like',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(s.temp(c.feelsC), style: _big(40)),
          const Spacer(),
          Text(why, style: _note, maxLines: 3, overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }
}

// ------------------------------------------------------------ pressure ---

class PressureTile extends StatelessWidget {
  final AppState s;
  final CurrentWeather c;
  const PressureTile({super.key, required this.s, required this.c});

  @override
  Widget build(BuildContext context) {
    final hpa = c.pressure;
    final value = s.imperial
        ? (hpa * 0.0295300).toStringAsFixed(2)
        : hpa.round().toString();
    final unit = s.imperial ? 'inHg' : 'hPa';
    final frac = ((hpa - 980) / 60).clamp(0.0, 1.0).toDouble();
    return DetailTile(
      icon: Icons.speed_rounded,
      title: 'Pressure',
      child: LayoutBuilder(builder: (_, box) {
        final d = math.min(box.maxWidth, box.maxHeight);
        return Center(
          child: SizedBox(
            width: d,
            height: d,
            child: Stack(
              alignment: Alignment.center,
              children: [
                CustomPaint(size: Size(d, d), painter: _DialPainter(frac)),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(value, style: _big(d * 0.18)),
                    Text(unit,
                        style: const TextStyle(color: _soft, fontSize: 11)),
                  ],
                ),
                Positioned(
                  bottom: 2,
                  left: 0,
                  right: 0,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: const [
                      Text('Low', style: TextStyle(color: _soft, fontSize: 10)),
                      Text('High', style: TextStyle(color: _soft, fontSize: 10)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      }),
    );
  }
}

class _DialPainter extends CustomPainter {
  final double frac;
  _DialPainter(this.frac);

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2 - 4;
    const start = math.pi * 0.75, sweep = math.pi * 1.5;
    for (var i = 0; i <= 40; i++) {
      final a = start + sweep * i / 40;
      final on = i / 40 <= frac + 0.001;
      canvas.drawLine(
        c + Offset(math.cos(a), math.sin(a)) * (r - 8),
        c + Offset(math.cos(a), math.sin(a)) * r,
        Paint()
          ..color = on ? Colors.white : _faint
          ..strokeWidth = 2
          ..strokeCap = StrokeCap.round,
      );
    }
    final a = start + sweep * frac;
    canvas.drawCircle(c + Offset(math.cos(a), math.sin(a)) * (r - 4), 5,
        Paint()..color = Colors.white);
  }

  @override
  bool shouldRepaint(_DialPainter old) => old.frac != frac;
}
