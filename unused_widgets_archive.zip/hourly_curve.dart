import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:intl/intl.dart' show DateFormat;

import '../models/weather.dart';
import '../utils/weather_codes.dart';
import 'weather_icon.dart';

const _colW = 58.0;
const _curveH = 70.0;

/// 24 hours as a smooth temperature line: hour labels and condition icons on
/// top, the curve with temperatures riding on it, and rain-chance bars along
/// the bottom. Scrolls horizontally.
class HourlyCurve extends StatelessWidget {
  final List<HourlyPoint> hours;
  final double Function(double c) toUnit;
  const HourlyCurve({super.key, required this.hours, required this.toUnit});

  @override
  Widget build(BuildContext context) {
    if (hours.isEmpty) return const SizedBox.shrink();
    final width = hours.length * _colW;
    return SizedBox(
      height: 196,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        child: SizedBox(
          width: width,
          child: Column(
            children: [
              Row(
                children: [
                  for (var i = 0; i < hours.length; i++)
                    SizedBox(
                      width: _colW,
                      child: Column(
                        children: [
                          Text(
                            i == 0 ? 'Now' : DateFormat('ha').format(hours[i].time).toLowerCase(),
                            style: TextStyle(
                              color: i == 0 ? Colors.white : Colors.white70,
                              fontSize: 12,
                              fontWeight:
                                  i == 0 ? FontWeight.w800 : FontWeight.w500,
                            ),
                          ),
                          const SizedBox(height: 8),
                          WeatherIcon(hours[i].code,
                              day: isDayHour(hours[i].time), size: 24),
                        ],
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 6),
              CustomPaint(
                size: Size(width, _curveH + 28),
                painter: _CurvePainter(
                  temps: [for (final h in hours) toUnit(h.tempC)],
                ),
              ),
              const SizedBox(height: 4),
              Row(
                children: [
                  for (final h in hours)
                    SizedBox(
                      width: _colW,
                      child: _RainBar(prob: h.precipProb),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RainBar extends StatelessWidget {
  final int prob;
  const _RainBar({required this.prob});

  @override
  Widget build(BuildContext context) {
    final p = (prob / 100).clamp(0.0, 1.0).toDouble();
    return Column(
      children: [
        Container(
          width: 22,
          height: 18,
          alignment: Alignment.bottomCenter,
          decoration: BoxDecoration(
            // Only show the trough when there's some chance of rain; dry
            // hours stay quiet.
            color: prob >= 10 ? Colors.white.withAlpha(18) : null,
            border: prob >= 10
                ? null
                : const Border(
                    bottom: BorderSide(color: Color(0x33FFFFFF), width: 2)),
            borderRadius: prob >= 10 ? BorderRadius.circular(5) : null,
          ),
          child: prob < 10 ? null : FractionallySizedBox(
            heightFactor: math.max(p, 0.001),
            widthFactor: 1,
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: Color.lerp(const Color(0xFF7FD3FF),
                    const Color(0xFF2E9BFF), p),
                borderRadius: BorderRadius.circular(5),
              ),
            ),
          ),
        ),
        const SizedBox(height: 3),
        Text(
          prob >= 10 ? '$prob%' : '',
          style: TextStyle(
            color: prob >= 30 ? const Color(0xFFA8E2FF) : Colors.white38,
            fontSize: 10,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}

class _CurvePainter extends CustomPainter {
  final List<double> temps;
  _CurvePainter({required this.temps});

  @override
  void paint(Canvas canvas, Size size) {
    if (temps.isEmpty) return;
    final lo = temps.reduce(math.min), hi = temps.reduce(math.max);
    final range = math.max(hi - lo, 1.0);
    const top = 24.0; // room for labels above the line
    final pts = <Offset>[
      for (var i = 0; i < temps.length; i++)
        Offset(_colW * i + _colW / 2,
            top + (1 - (temps[i] - lo) / range) * (_curveH - 8)),
    ];

    // Smooth path through the points (Catmull-Rom → cubic Bézier).
    final path = Path()..moveTo(pts.first.dx, pts.first.dy);
    for (var i = 0; i < pts.length - 1; i++) {
      final p0 = i == 0 ? pts[i] : pts[i - 1];
      final p1 = pts[i];
      final p2 = pts[i + 1];
      final p3 = i + 2 < pts.length ? pts[i + 2] : p2;
      final c1 = p1 + (p2 - p0) / 6;
      final c2 = p2 - (p3 - p1) / 6;
      path.cubicTo(c1.dx, c1.dy, c2.dx, c2.dy, p2.dx, p2.dy);
    }

    // Soft fill under the line.
    final fill = Path.from(path)
      ..lineTo(pts.last.dx, size.height)
      ..lineTo(pts.first.dx, size.height)
      ..close();
    canvas.drawPath(
      fill,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Colors.white.withAlpha(60), Colors.white.withAlpha(0)],
        ).createShader(Offset.zero & size),
    );

    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5
        ..strokeCap = StrokeCap.round
        ..shader = const LinearGradient(colors: [
          Color(0xFFFFE29A),
          Color(0xFFFFFFFF),
          Color(0xFFA8E2FF),
        ]).createShader(Offset.zero & size),
    );

    final iHi = temps.indexOf(hi), iLo = temps.indexOf(lo);
    for (var i = 0; i < pts.length; i++) {
      final now = i == 0;
      // Dots and labels every other hour keep it calm; always label now,
      // the high and the low.
      final label = now || i == iHi || i == iLo || i.isEven;
      if (now) {
        canvas.drawCircle(pts[i], 7, Paint()..color = Colors.white.withAlpha(70));
      }
      canvas.drawCircle(
          pts[i], now ? 4.5 : 2.5, Paint()..color = Colors.white);
      if (!label) continue;
      final tp = TextPainter(
        text: TextSpan(
          text: '${temps[i].round()}°',
          style: TextStyle(
            color: Colors.white,
            fontSize: now ? 15 : 13,
            fontWeight: now ? FontWeight.w800 : FontWeight.w600,
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, pts[i] - Offset(tp.width / 2 - 3, tp.height + 6));
    }
  }

  @override
  bool shouldRepaint(_CurvePainter old) => old.temps != temps;
}
